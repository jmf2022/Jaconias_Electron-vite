export function Detail(){
  return (
    <div>
      <h1>Página Detalhe do cliente!!!</h1>
    </div>
  )
}